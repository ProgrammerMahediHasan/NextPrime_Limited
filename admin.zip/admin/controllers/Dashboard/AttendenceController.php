<?php

class AttendenceController {

    // ===============================
    // 1. Show all employees (attendance records)
    // ===============================
    public function index() {
        $attendences = Attendence::getAll();
        view("dashboard", $attendences);
    }

    // ===============================
    // 2. Show create form
    // ===============================
    public function create() {
        view("dashboard");
    }

    // ===============================
    // 3. Save new attendance
    // ===============================
    public function save($data) {
        if (isset($_POST['create'])) {

            // Remove atten_id on create, ID is auto-increment
            // $atten_id   = $_POST['atten_id'];
            $id       = $_POST['id'];
            $atten_date   = $_POST['atten_date'];
            $emp_status   = $_POST['emp_status'];
            $time_in      = $_POST['time_in'];
            $time_out     = $_POST['time_out'];
            $remarks      = $_POST['remarks'];
            $created_time = $_POST['created_time'];

            $attendence = new Attendence(
                null, // no ID for new record
                $id, $atten_date, $emp_status, $time_in,
                $time_out, $remarks, $created_time
            );

            $attendence->save();
            redirect(); // keep your original redirect
        }
    }

    // ===============================
    // 4. Show edit form
    // ===============================
    public function edit($id) {
        $attendence = Attendence::find($id);
        view("dashboard", $attendence);
    }

    // ===============================
    // 5. Update attendance
    // ===============================
    public function update($data) {
        if (isset($_POST['update'])) {

            $atten_id     = $_POST['atten_id'];
            $id       = $_POST['id'];
            $atten_date   = $_POST['atten_date'];
            $emp_status   = $_POST['emp_status'];
            $time_in      = $_POST['time_in'];
            $time_out     = $_POST['time_out'];
            $remarks      = $_POST['remarks'];
            $created_time = $_POST['created_time'];

            $attendence = new Attendence(
                $atten_id, $id, $atten_date, $emp_status, $time_in,
                $time_out, $remarks, $created_time
            );

            $attendence->update();
            redirect(); // keep your original redirect
        }
    }

    // ===============================
    // 6. Delete attendance
    // ===============================
    public function delete($id) {
        Attendence::delete($id);
        redirect();
    }
}
?>
