<?php
class Designation extends Model implements JsonSerializable
{
	public $id;
	public $dept_id;
	public $name;
	public $description;


	public function __construct() {}

	public function set($id,$dept_id,$name,$description)
	{
		$this->id = $id;
		$this->dept_id = $dept_id;
		$this->name = $name;
		$this->description = $description;
	}


	/* ==============================
	   SAVE
	============================== */
	public function save()
	{
		global $db, $tx;

		$db->query("insert into {$tx}designations(dept_id,name,description)
		            values('$this->dept_id','$this->name','$this->description')");

		return $db->insert_id;
	}


	/* ==============================
	   UPDATE
	============================== */
	public function update()
	{
		global $db, $tx;

		$sql = "UPDATE {$tx}designations 
		        SET dept_id = '{$this->dept_id}', 
		            name = '{$this->name}', 
		            description = '{$this->description}' 
		        WHERE id = '{$this->id}'";

		$db->query($sql);
	}


	/* ==============================
	   DELETE
	============================== */
	public static function delete($id)
	{
		global $db, $tx;
		$db->query("delete from {$tx}designations where id={$id}");
	}


	public function jsonSerialize(): mixed
	{
		return get_object_vars($this);
	}


	/* ==============================
	   GET ALL (JOIN ADDED ONLY)
	============================== */
public static function getall($dept_id = null)
{
    global $db, $tx;

    $sql = "SELECT id, name FROM {$tx}designations";
    if ($dept_id) {
        $dept_id = intval($dept_id); // security
        $sql .= " WHERE dept_id = $dept_id";
    }

    $result = $db->query($sql);
    $data = [];
    while ($row = $result->fetch_object()) {
        $data[] = $row;
    }
    return $data;
}



	/* ==============================
	   PAGINATION (JOIN ADDED ONLY)
	============================== */
	public static function pagination($page = 1, $perpage = 10, $criteria = "")
	{
		global $db, $tx;

		$top = ($page - 1) * $perpage;

		$result = $db->query("
			select d.id,d.name,d.description,d.dept_id,
			       dep.name as dept_name
			from {$tx}designations d
			join {$tx}department dep on dep.id=d.dept_id
			$criteria
			limit $top,$perpage
		");

		$data = [];
		while ($designation = $result->fetch_object()) {
			$data[] = $designation;
		}
		return $data;
	}


	/* ==============================
	   COUNT
	============================== */
	public static function count($criteria = "")
	{
		global $db, $tx;

		$result = $db->query("select count(*) from {$tx}designations $criteria");
		list($count) = $result->fetch_row();

		return $count;
	}


	/* ==============================
	   FIND (JOIN ADDED ONLY)
	============================== */
	public static function find($id)
	{
		global $db, $tx;

		$result = $db->query("
			select d.id,d.name,d.description,d.dept_id,
			       dep.name as dept_name
			from {$tx}designations d
			join {$tx}department dep on dep.id=d.dept_id
			where d.id='$id'
		");

		return $result->fetch_object();
	}


	/* ==============================
	   HTML SELECT (UNCHANGED)
	============================== */
	static function html_select($name = "cmbDesignation")
	{
		global $db, $tx;

		$html = "<select id='$name' name='$name'> ";

		$result = $db->query("select id,name from {$tx}designations");

		while ($designation = $result->fetch_object()) {
			$html .= "<option value ='$designation->id'>$designation->name</option>";
		}

		$html .= "</select>";

		return $html;
	}


	/* ==============================
	   HTML TABLE (ONLY dept name change)
	============================== */
	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true)
	{
		global $db, $tx, $base_url;

		$count_result = $db->query("SELECT COUNT(*) total FROM {$tx}designations $criteria");
		list($total_rows) = $count_result->fetch_row();

		$total_pages = ceil($total_rows / $perpage);
		$top = ($page - 1) * $perpage;

		// Fetch designation data
$result = $db->query("
    SELECT d.id, d.name, d.description, d.dept_id, dep.name AS dept_name
    FROM {$tx}designations d
    JOIN {$tx}department dep ON dep.id = d.dept_id
    $criteria
    LIMIT $top, $perpage
");

// === Professional CSS Styling with borders ===
$html = "<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

.dept-card {
    max-width: 1100px;
    margin: 25px auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    font-family: 'Poppins', sans-serif;
    overflow: hidden;
    border: 1px solid #e2e8f0;
}
.dept-card-header {
    background: linear-gradient(135deg,#2563eb,#1d4ed8);
    color: #fff;
    padding: 18px 25px;
    font-size: 20px;
    font-weight: 600;
    text-align: center;
}
.dept-card-body {
    padding: 20px 25px;
    overflow-x: auto;
}
.dept-table {
    width: 100%;
    border-collapse: collapse;
}
.dept-table th, .dept-table td {
    padding: 10px 12px;
    text-align: center;
    font-size: 14px;
    border: 1px solid #e2e8f0;
    word-wrap: break-word;
}
.dept-table th {
    background-color: #1f3d79ff;
    font-weight: 600;
    color: #e7e8eba9;
}
.btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px;
    flex-wrap: nowrap;
}
.btn-group button {
    padding: 6px 10px !important;
    font-size: 14px !important;
    border-radius: 4px;
    border: 2px solid #000;
    outline: none;
    cursor: pointer;
    color: #fff;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
}
.btn-group i {
    font-weight: 900;
}
.btn-group button:focus {
    outline: none;
    border: 1px solid rgba(0,0,0,0.3);
    box-shadow: none;
}
.btn-primary { background: #3b82f6; }
.btn-danger { background: #ef4444; }
.dept-table tr:hover { background: #f1f5f9; transition: 0.2s; }
@media (max-width: 768px) {
    .dept-table th, .dept-table td { font-size: 12px; padding: 6px 8px; }
    .btn-group button { font-size: 10px; padding: 3px 5px; }
}
</style>";

$html .= "<div class='dept-card'>";
$html .= "<div class='dept-card-header'>Designation Section</div>";
$html .= "<div class='dept-card-body'>";

// New Designation Button
$html .= "<div style='margin-bottom:10px; text-align:right;'>
            <a href='{$base_url}/designation/create' class='btn btn-success' style='padding:6px 12px;'>+ Add Designation</a>
          </div>";

// Table Start
$html .= "<table class='dept-table'>";
$html .= "<tr>
            <th>ID</th>
            <th>Department</th>
            <th>Designation</th>
            <th>Description</th>";
if($action) $html .= "<th>Action</th>";
$html .= "</tr>";

// Table Rows
while($designation = $result->fetch_object()){
    $html .= "<tr>
                <td>$designation->id</td>
                <td>$designation->dept_name</td>
                <td>$designation->name</td>
                <td>$designation->description</td>";

    if($action){
        $html .= "<td style='white-space: nowrap;'>
                    <div class='btn-group'>
                        <button class='btn-primary' onclick=\"location.href='{$base_url}/designation/edit/$designation->id'\"><i class='fas fa-edit'></i></button>
                        <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/designation/confirm/$designation->id'\"><i class='fas fa-trash-alt'></i></button>
                    </div>
                  </td>";
    }

    $html .= "</tr>";
}

$html .= "</table>";

// Pagination
$html .= "<div style='margin-top:10px; text-align:center;'>" . pagination($page, $total_pages) . "</div>";

$html .= "</div></div>";

return $html;

}
}