<?php
class LeaveRequest extends Model implements JsonSerializable{
	public $id;
	public $emp_id;
	public $leave_id;
	public $start_date;
	public $end_date;
	public $total_days;
	public $reason;
	public $status;
	public $approver_id;
	public $applied_on;

	public function __construct(){}

	public function set($id,$emp_id,$leave_id,$start_date,$end_date,$total_days,$reason,$status,$approver_id,$applied_on){
		$this->id = $id;
		$this->emp_id = $emp_id;
		$this->leave_id = $leave_id;
		$this->start_date = $start_date;
		$this->end_date = $end_date;
		$this->total_days = $total_days;
		$this->reason = $reason;
		$this->status = $status;
		$this->approver_id = $approver_id;
		$this->applied_on = $applied_on;
	}

	public function save(){
		global $db,$tx;
		$db->query("INSERT INTO {$tx}leave_request(emp_id,leave_id,start_date,end_date,total_days,reason,status,approver_id,applied_on)
			VALUES('$this->emp_id','$this->leave_id','$this->start_date','$this->end_date','$this->total_days','$this->reason','$this->status','$this->approver_id','$this->applied_on')");
		
		$last_id = $db->insert_id;

		// যদি status Approved হয় তাহলে leave_assign update করো
		if(strtolower($this->status) == 'approved'){
			self::updateLeaveAssignUsedDays($this->emp_id, $this->leave_id);
		}

		return $last_id;
	}

	public function update(){
		global $db,$tx;
		$db->query("UPDATE {$tx}leave_request SET 
			emp_id='$this->emp_id',
			leave_id='$this->leave_id',
			start_date='$this->start_date',
			end_date='$this->end_date',
			total_days='$this->total_days',
			reason='$this->reason',
			status='$this->status',
			approver_id='$this->approver_id',
			applied_on='$this->applied_on'
			WHERE id='$this->id'");

		// যদি status Approved হয় তাহলে leave_assign update করো
		if(strtolower($this->status) == 'approved'){
			self::updateLeaveAssignUsedDays($this->emp_id, $this->leave_id);
		}
	}

	public static function delete($id){
		global $db,$tx;
		$db->query("DELETE FROM {$tx}leave_request WHERE id='$id'");
	}

	public function jsonSerialize():mixed{
		return get_object_vars($this);
	}

	public static function all(){
		global $db,$tx;
		$result=$db->query("SELECT id,emp_id,leave_id,start_date,end_date,total_days,reason,status,approver_id,applied_on FROM {$tx}leave_request");
		$data=[];
		while($row=$result->fetch_object()){
			$data[]=$row;
		}
		return $data;
	}

	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("SELECT id,emp_id,leave_id,start_date,end_date,total_days,reason,status,approver_id,applied_on FROM {$tx}leave_request $criteria LIMIT $top,$perpage");
		$data=[];
		while($row=$result->fetch_object()){
			$data[]=$row;
		}
		return $data;
	}

	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("SELECT COUNT(*) FROM {$tx}leave_request $criteria");
		list($count)=$result->fetch_row();
		return $count;
	}

	public static function find($id){
		global $db,$tx;
		$result =$db->query("SELECT id,emp_id,leave_id,start_date,end_date,total_days,reason,status,approver_id,applied_on 
			FROM {$tx}leave_request WHERE id='$id'");
		return $result->fetch_object();
	}

	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("SELECT MAX(id) last_id FROM {$tx}leave_request");
		$row =$result->fetch_object();
		return $row->last_id;
	}

	public function json(){
		return json_encode($this);
	}

	public function __toString(){
		return "
		Emp Id: $this->emp_id<br>
		Leave Type: $this->leave_id<br>
		Start Date: $this->start_date<br>
		End Date: $this->end_date<br>
		Total Days: $this->total_days<br>
		Reason: $this->reason<br>
		Status: $this->status<br>
		Approver Id: $this->approver_id<br>
		";
	}

	//-------------HTML----------//
	static function html_select($name="cmbLeaveRequest"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("SELECT id,emp_id FROM {$tx}leave_request");
		while($row=$result->fetch_object()){
			$html.="<option value='$row->id'>$row->emp_id</option>";
		}
		$html.="</select>";
		return $html;
	}

	// LeaveRequest table with styling
	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true){
		global $db, $tx, $base_url;

		$count_result = $db->query("SELECT COUNT(*) total FROM {$tx}leave_request lr
			LEFT JOIN {$tx}employees e ON e.id = lr.emp_id
			LEFT JOIN {$tx}leave_types lt ON lt.id = lr.leave_id
			$criteria");
		list($total_rows) = $count_result->fetch_row();
		$total_pages = ceil($total_rows / $perpage);
		$top = ($page - 1) * $perpage;

		$result = $db->query("SELECT
				lr.id,
				e.name AS employee_name,
				lt.name AS leave_type_name,
				lr.start_date,
				lr.end_date,
				lr.total_days,
				lr.reason,
				lr.status,
				lr.approver_id,
				lr.applied_on
			FROM {$tx}leave_request lr
			LEFT JOIN {$tx}employees e ON e.id = lr.emp_id
			LEFT JOIN {$tx}leave_types lt ON lt.id = lr.leave_id
			$criteria
			LIMIT $top,$perpage");

		$html = "<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
		.table-responsive{ overflow-x:auto; }
		.table-responsive table{ width:100%; border-collapse:collapse; table-layout:fixed; font-family:'Poppins',sans-serif; }
		.table-responsive th{ background:#1f3d79ff; color:#fff; font-weight:700; text-align:center; padding:8px; font-size:13px; border:1px solid #fff; }
		.table-responsive td{ text-align:center; vertical-align:middle; padding:6px 8px; font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; border:1px solid #000; }
		.table-responsive tr:hover{ background:#f1f5f9; transition:0.2s; }
		.table-top{ display:flex; justify-content:flex-start; margin-bottom:8px; }
		.btn-add{ background:#1f3d79ff; color:#fff; border:1px solid #fff; padding:6px 12px; font-weight:700; border-radius:4px; cursor:pointer; font-size:13px; }
		.btn-group{ display:flex !important; justify-content:center; gap:6px; flex-wrap:nowrap; }
		.btn-group button{ padding:6px 10px !important; font-size:14px !important; border-radius:4px; border:2px solid #000; cursor:pointer; color:#fff; font-weight:700; display:flex; align-items:center; justify-content:center; }
		.btn-primary{ background:#3b82f6; }
		.btn-danger{ background:#ef4444; }
		@media(max-width:768px){ .table-responsive table th, .table-responsive table td{ font-size:11px; padding:5px 6px; } .btn-group button{ font-size:10px !important; width:26px; height:26px; padding:2px 5px !important; } }
		</style>";

		$html .= "<div class='table-top'>
			<button class='btn-add' onclick=\"location.href='{$base_url}/leaverequest/create'\">
				+ Add Leave Request
			</button>
		</div>";

		$html .= "<div class='table-responsive'>
		<table class='table table-striped table-hover'>
		<thead>
			<tr>
				<th>Employee Name</th>
				<th>Leave Type</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Total Days</th>
				<th>Reason</th>
				<th>Status</th>
				<th>Approver ID</th>";
		if($action) $html .= "<th>Action</th>";
		$html .= "</tr>
		</thead><tbody>";

		while($lr = $result->fetch_object()){
			$action_buttons = "";
			if($action){
				$action_buttons = "<td>
					<div class='btn-group'>
						<button class='btn-primary' onclick=\"location.href='{$base_url}/leaverequest/edit/$lr->id'\">
							<i class='fas fa-edit'></i>
						</button>
						<button class='btn-danger' onclick=\"if(confirm('Are you sure to delete this Leave Request?'))
							location.href='{$base_url}/leaverequest/delete/$lr->id'\">
							<i class='fas fa-trash-alt'></i>
						</button>
					</div>
				</td>";
			}

			$html .= "<tr>
				<td>{$lr->employee_name}</td>
				<td>{$lr->leave_type_name}</td>
				<td>{$lr->start_date}</td>
				<td>{$lr->end_date}</td>
				<td>{$lr->total_days}</td>
				<td>{$lr->reason}</td>
				<td>{$lr->status}</td>
				<td>{$lr->approver_id}</td>
				$action_buttons
			</tr>";
		}

		$html .= "</tbody></table></div>";
		$html .= pagination($page,$total_pages);

		return $html;
	}

	static function html_row_details($id){
		global $db,$tx;

		$result = $db->query("SELECT id,emp_id,leave_id,start_date,end_date,total_days,reason,status,approver_id,applied_on 
			FROM {$tx}leave_request WHERE id='$id'");
		
		if(!$result || $result->num_rows == 0){
			return "<div>No data found</div>";
		}

		$lr = $result->fetch_object();

		$html = "<table class='table table-bordered'>
			<tr><th>ID</th><td>$lr->id</td></tr>
			<tr><th>Emp ID</th><td>$lr->emp_id</td></tr>
			<tr><th>Leave Type</th><td>$lr->leave_id</td></tr>
			<tr><th>Start Date</th><td>$lr->start_date</td></tr>
			<tr><th>End Date</th><td>$lr->end_date</td></tr>
			<tr><th>Total Days</th><td>$lr->total_days</td></tr>
			<tr><th>Reason</th><td>$lr->reason</td></tr>
			<tr><th>Status</th><td>$lr->status</td></tr>
			<tr><th>Approver ID</th><td>$lr->approver_id</td></tr>
			<tr><th>Applied On</th><td>$lr->applied_on</td></tr>
		</table>";
		return $html;
	}

	// ============================
	// নতুন ফাংশন: leave_assign used_days update
	public static function updateLeaveAssignUsedDays($emp_id, $leave_id){
		global $db, $tx;

		$result = $db->query("
			SELECT SUM(total_days) as total_used 
			FROM {$tx}leave_request 
			WHERE emp_id='$emp_id' AND leave_id='$leave_id' AND status='Approved'
		");
		$row = $result->fetch_object();
		$total_used = $row->total_used ?? 0;

		$db->query("
			UPDATE {$tx}leave_assign 
			SET used_days='$total_used' 
			WHERE emp_id='$emp_id' AND leave_type_id='$leave_id'
		");
	}

}
?>
