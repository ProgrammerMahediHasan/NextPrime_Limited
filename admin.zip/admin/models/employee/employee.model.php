<?php
class Employee extends Model implements JsonSerializable
{
    public $id;
    public $name;
    public $dept_id;
    public $desig_id;
    public $email;
    public $phone;
    public $status;

    // ✅ Keep only new fields
    public $gender;
    public $joining_date;

    public function __construct() {}

    // ✅ Updated set method (removed basic_salary)
    public function set($id, $name, $dept_id, $desig_id, $email, $phone, $status, $gender, $joining_date)
    {
        $this->id = $id;
        $this->name = $name;
        $this->dept_id = $dept_id;
        $this->desig_id = $desig_id;
        $this->email = $email;
        $this->phone = $phone;
        $this->status = $status;
        $this->gender = $gender;
        $this->joining_date = $joining_date;
    }

    public function save()
    {
        global $db, $tx;
        $db->query("INSERT INTO {$tx}employees(name, dept_id, desig_id, email, phone, status, gender, joining_date)
			VALUES('$this->name', '$this->dept_id', '$this->desig_id', '$this->email', '$this->phone', '$this->status', '$this->gender', '$this->joining_date')");
        return $db->insert_id;
    }

    public function update()
    {
        global $db, $tx;
        $db->query("UPDATE {$tx}employees 
			SET name='$this->name', dept_id='$this->dept_id', desig_id='$this->desig_id', 
				email='$this->email', phone='$this->phone', status='$this->status', 
				gender='$this->gender', joining_date='$this->joining_date'
			WHERE id='$this->id'");
    }

    public static function delete($id)
    {
        global $db, $tx;
        $db->query("DELETE FROM {$tx}employees WHERE id={$id}");
    }
    public static function payslip($id, $salary_month)
    {
        global $db, $tx;

        $data = null;
        $employee_id  = $id;
        $salary_month = $salary_month;

        if ($employee_id && $salary_month) {

            $stmt = $db->prepare("
        SELECT
            es.emp_id,
            es.basic_salary,
            es.hra,
            es.medical_allowance,
            es.tax_deduction,
            es.pf_deduction,
            es.gross_salary,
            es.net_salary,

            e.id   AS employee_id,
            e.name AS employee_name,
            e.email,
            e.phone,

            d.name   AS department_name,
            des.name AS designation_name,

            ? AS salary_month,
            CURDATE() AS generated_at,

            COALESCE(SUM(
                CASE 
                    WHEN la.used_days > lt.total_days 
                    THEN ((la.used_days - lt.total_days) / 30) * es.basic_salary
                    ELSE 0
                END
            ),0) AS leave_deduct

        FROM employee_salary es
        JOIN employees e ON es.emp_id = e.id
        LEFT JOIN department d ON e.dept_id = d.id
        LEFT JOIN designations des ON e.desig_id = des.id
        LEFT JOIN leave_assign la ON la.emp_id = es.emp_id
        LEFT JOIN leave_types lt ON lt.id = la.leave_type_id

        WHERE es.emp_id = ?

        GROUP BY es.id
        ORDER BY es.id DESC
        LIMIT 1
        ");

            $stmt->bind_param("si", $salary_month, $employee_id);
            $stmt->execute();
            $data = $stmt->get_result()->fetch_assoc();
        }
        return $data;

    }


    public static function emp_info()
    {
        global $db, $tx;
        $result = $db->query(" SELECT e.id, e.name, d.name AS department, ds.name AS designation, e.gender, e.email, e.phone, e.basic_salary, e.status, e.joining_date
        FROM {$tx}employees e
        LEFT JOIN {$tx}department d ON e.dept_id = d.id
        LEFT JOIN {$tx}designations ds ON e.desig_id = ds.id
        ORDER BY e.id ASC");
        $data = [];
        while ($employee = $result->fetch_object()) {
            $data[] = $employee;
        }
        return $data;
    }



    public function jsonSerialize(): mixed
    {
        return get_object_vars($this);
    }



    public static function all()
    {
        global $db, $tx;
        $result = $db->query("SELECT id, name, dept_id, desig_id, email, phone, status, gender, joining_date FROM {$tx}employees");
        $data = [];
        while ($employee = $result->fetch_object()) {
            $data[] = $employee;
        }
        return $data;
    }
    // public static function allwithName()
    // {
    //     global $db, $tx;
    //     $result = $db->query("
    //         SELECT e.id, e.name, d.name AS department, ds.name AS designation, e.gender, e.email, e.phone, e.basic_salary, e.status, e.joining_date
    //         FROM {$tx}employees e
    //         LEFT JOIN {$tx}department d ON e.dept_id = d.id
    //         LEFT JOIN {$tx}designations ds ON e.desig_id = ds.id

    //         ORDER BY e.id ASC
    //       ");
    //     $data = [];
    //     while ($employee = $result->fetch_object()) {
    //         $data[] = $employee;
    //     }
    //     return $data;
    // }

    public static function pagination($page = 1, $perpage = 10, $criteria = "")
    {
        global $db, $tx;
        $top = ($page - 1) * $perpage;
        $result = $db->query("SELECT id, name, dept_id, desig_id, email, phone, status, gender, joining_date 
							  FROM {$tx}employees $criteria LIMIT $top, $perpage");
        $data = [];
        while ($employee = $result->fetch_object()) {
            $data[] = $employee;
        }
        return $data;
    }

    public static function count($criteria = "")
    {
        global $db, $tx;
        $result = $db->query("SELECT COUNT(*) FROM {$tx}employees $criteria");
        list($count) = $result->fetch_row();
        return $count;
    }

    public static function find($id)
    {
        global $db, $tx;
        $result = $db->query("SELECT id, name, dept_id, desig_id, email, phone, status, gender, joining_date 
							  FROM {$tx}employees WHERE id='$id'");
        return $result->fetch_object();
    }

    static function get_last_id()
    {
        global $db, $tx;
        $result = $db->query("SELECT MAX(id) last_id FROM {$tx}employees");
        $employee = $result->fetch_object();
        return $employee->last_id;
    }

    public function json()
    {
        return json_encode($this);
    }

    public function __toString()
    {
        return "Id: $this->id<br>
				Name: $this->name<br>
				Dept Id: $this->dept_id<br>
				Desig Id: $this->desig_id<br>
				Email: $this->email<br>
				Phone: $this->phone<br>
				Status: $this->status<br>
				Gender: $this->gender<br>
				Joining Date: $this->joining_date<br>";
    }

    //-------------HTML----------//

    static function html_select($name = "cmbEmployee")
    {
        global $db, $tx;
        $html = "<select id='$name' name='$name' class='form-control'>";
        $result = $db->query("SELECT id, name FROM {$tx}employees");
        while ($employee = $result->fetch_object()) {
            $html .= "<option value ='$employee->id'>$employee->name</option>";
        }
        $html .= "</select>";
        return $html;
    }


    static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true)
    {
        global $db, $tx, $base_url;

        $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}employees $criteria");
        list($total_rows) = $count_result->fetch_row();
        $total_pages = ceil($total_rows / $perpage);
        $top = ($page - 1) * $perpage;

        $result = $db->query("SELECT e.id, e.name, d.name AS dept_name, ds.name AS desig_name, e.email, e.phone, e.status, e.gender, e.joining_date
                          FROM {$tx}employees e
                          LEFT JOIN {$tx}department d ON e.dept_id = d.id
                          LEFT JOIN {$tx}designations ds ON e.desig_id = ds.id
                          $criteria LIMIT $top, $perpage");

        $html = "<style>
    .table-responsive { overflow-x: auto; }
    .table-responsive table {
        width: 100%; 
        border-collapse: collapse; 
        table-layout: fixed; 
        font-family: 'Poppins', sans-serif;
    }
    .table-responsive table th {
        font-weight: 700;
        text-align: center;
        background-color: #1f3d79ff;
        color: #fff;
        padding: 8px;
        font-size: 13px;
    }
    .table-responsive table td {
        text-align: center;
        vertical-align: middle;
        padding: 6px 8px;
        font-size: 12px;
        word-wrap: break-word;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .table-responsive table td.email-col {
        max-width: 130px;
    }
    .table-responsive table td .btn-group {
        display: flex !important;
        justify-content: center;
        gap: 4px;
        flex-wrap: nowrap;
    }
    .table-responsive table td .btn-group button {
        padding: 4px 6px !important;
        font-size: 12px !important;
        width: 28px;
        height: 28px;
        line-height: 1;
    }
    .table-responsive table td .btn-group i {
        font-size: 14px;
    }
    .table-responsive table tr:hover {
        background-color: #f1f5f9;
        transition: 0.2s;
    }

    .btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group button {
    padding: 6px 10px !important; /* একটু বড় padding */
    font-size: 14px !important;   /* icon বড় দেখানোর জন্য */
    border-radius: 4px;
    border: 2px solid #000;       /* গাঢ় black border */
    outline: none;
    cursor: pointer;
    color: #fff;
    font-weight: 700;              /* icon/text bold */
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-group i {
    font-weight: 900; /* icon আরও bold */
}


.btn-group button:focus {
    outline: none;
    border: 1px solid rgba(0,0,0,0.3);
    box-shadow: none;
}

.btn-primary { background: #3b82f6; }
    .btn-danger { background: #ef4444; }

    @media (max-width: 768px) {
        .table-responsive table td, .table-responsive table th {
            font-size: 11px;
            padding: 5px 6px;
        }
        .table-responsive table td .btn-group button {
            font-size: 10px;
            padding: 2px 5px;
            width: 26px;
            height: 26px;
        }
        .table-responsive table td .btn-group i {
            font-size: 12px;
        }
    }
    </style>";

        $html .= "<div class='table-responsive'>";
        $html .= "<table class='table table-bordered table-striped table-hover'>";
        $html .= "<tr><th colspan='" . ($action ? 10 : 9) . "' class='text-center'>"
            . Html::link(["class" => "btn btn-success", "route" => "employee/create", "text" => "+ Add Employee"])
            . "</th></tr>";

        $html .= "<tr>
                <th>Emp Id</th>
                <th>Name</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Gender</th>
                <th>Joining Date</th>";
        if ($action) $html .= "<th>Action</th>";
        $html .= "</tr>";

        while ($employee = $result->fetch_object()) {
            $html .= "<tr>
                    <td>$employee->id</td>
                    <td>$employee->name</td>
                    <td title='$employee->dept_name'>$employee->dept_name</td>
                    <td title='$employee->desig_name'>$employee->desig_name</td>
                    <td class='email-col' title='$employee->email'>$employee->email</td>
                    <td>$employee->phone</td>
                    <td>$employee->status</td>
                    <td>$employee->gender</td>
                    <td>$employee->joining_date</td>";
            if ($action) {
                $html .= "<td style='white-space: nowrap;'>
                        <div class='btn-group'>
                            <button class='btn-primary' onclick=\"location.href='{$base_url}/employee/edit/$employee->id'\"><i class='fas fa-edit'></i></button>
                            <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/employee/confirm/$employee->id'\"><i class='fas fa-trash-alt'></i></button>
                        </div>
                      </td>";
            }
            $html .= "</tr>";
        }

        $html .= "</table>";
        $html .= "</div>";
        $html .= pagination($page, $total_pages);
        return $html;
    }








    static function html_row_details($id)
    {
        global $db, $tx, $base_url;

        // join department and designation tables
        $result = $db->query("
        SELECT e.id, e.name, d.name AS dept_name, ds.name AS desig_name,
               e.email, e.phone, e.status, e.gender, e.joining_date
        FROM {$tx}employees e
        LEFT JOIN {$tx}department d ON e.dept_id = d.id
        LEFT JOIN {$tx}designations ds ON e.desig_id = ds.id
        WHERE e.id={$id}
    ");

        $employee = $result->fetch_object();

        $html = "<div class='table-responsive'>";
        $html .= "<table class='table table-bordered table-striped' style='table-layout: fixed; width: 100%;'>";
        $html .= "<tr><th colspan='2' class='text-center'>Employee Details</th></tr>";
        $html .= "<tr><th>Id</th><td>$employee->id</td></tr>";
        $html .= "<tr><th>Name</th><td>$employee->name</td></tr>";
        $html .= "<tr><th>Department</th><td>$employee->dept_name</td></tr>";
        $html .= "<tr><th>Designation</th><td>$employee->desig_name</td></tr>";
        $html .= "<tr><th>Email</th><td>$employee->email</td></tr>";
        $html .= "<tr><th>Phone</th><td>$employee->phone</td></tr>";
        $html .= "<tr><th>Status</th><td>$employee->status</td></tr>";
        $html .= "<tr><th>Gender</th><td>$employee->gender</td></tr>";
        $html .= "<tr><th>Joining Date</th><td>$employee->joining_date</td></tr>";
        $html .= "</table>";
        $html .= "</div>";

        return $html;
    }
}
