<?php   
   //Remote
   
     define("SERVER","localhost");
     define("USER","root");
     define("DATABASE","hrm");
     define("PASSWORD","");

     
    //  define("SERVER","localhost");
    //  define("USER","mahedi");
    //  define("DATABASE","wdpf66_mahedi");
    //  define("PASSWORD","1358@;;");


    $db=new mysqli(SERVER,USER,PASSWORD,DATABASE);
    $tx="rt_";
  

?>